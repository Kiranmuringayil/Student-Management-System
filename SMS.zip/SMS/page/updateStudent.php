<?php
include('../config/connection.php');

$uid = $_POST['uid'];
$fname = $_POST['fName'];
$lname = $_POST['lName'];
$mail = $_POST['mail'];
$grade = $_POST['selGrade'];
$branch = $_POST['selBranch'];
$joinDate = $_POST['joinDate'];

$ins = mysqli_query($conn,"update stu_tbl set fname ='$fname',lname = '$lname',mail = '$mail',
grade = '$grade',branch = '$branch',joinDate = '$joinDate' where id ='$uid'");
echo "update stu_tbl set 'fname' ='$fname',lname = '$lname',mail = '$mail',
grade = '$grade',branch = '$branch',joinDate = '$joinDate' where id ='$uid'";
if ($ins) {
    header('location:profile.php');
}
?>