 <?php
 session_start();
 if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="container-fluid">
     <div class="row bg-title">
         <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
             <h4 class="page-title">Dashboard</h4>
         </div>
     </div>
     <div class="row">
         <div class="col-md-12">
             <div class="white-box">
                 <h3 class="box-title">Grade Management</h3>
             </div>
         </div>
     </div>
     <div class="row">
         <div class="col-sm-12">
             <div class="white-box">
                 <h3 class="box-title">
                     <div class="row">
                         <div class="col-md-2">
                             <button class="btn btn-danger btn-block waves-effect waves-light" data-toggle="modal"
                                 data-target="#addGradeModal">
                                 <i class="fa fa-plus-circle">Add Grade</i></button>
                         </div>
                     </div>
                 </h3>
                 <div class="table-responsive">
                     <table class="table">
                         <thead>
                             <tr>
                                 <th>Id</th>
                                 <th>Grade</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php
                                $sel=mysqli_query($conn,"SELECT * FROM grade_tbl");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                             <tr>
                                 <td><?php echo $row['gradeId'];?></td>
                                 <td><?php echo $row['grade'];?></td>
                             </tr>
                             <?php
                                 }
                                }
                             ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>

 <!-- Modal -->
 <div class="modal fade" id="addGradeModal" tabindex="-1" role="dialog" aria-labelledby="addGradeModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <form method="post" action="gradeAction.php">
                     <div class="form-group">
                         <label for="grade">Grade</label>
                         <input required type="text" class="form-control" name="grade" id="grade" placeholder="Enter Grade">
                     </div>
                     <button type="submit" class="btn btn-primary">Enroll</button>
                 </form>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
             </div>
         </div>
     </div>
 </div>

 <?php
include('foot.php');
}
?>