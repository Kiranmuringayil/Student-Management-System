 <?php
 session_start();
 include('head.php');
 ?>
 <div class="container-fluid">
     <div class="row bg-title">
         <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
             <h4 class="page-title">Dashboard</h4>
         </div>
     </div>
     <div class="row">
         <div class="col-md-12">
             <div class="white-box">
                 <h3 class="box-title">Admin Management</h3>
             </div>
         </div>
     </div>
     <div class="row">
         <div class="col-sm-12">
             <div class="white-box">
                 <h3 class="box-title">
                     <div class="row">
                         <div class="col-md-2">
                             <button class="btn btn-danger btn-block waves-effect waves-light" data-toggle="modal"
                                 data-target="#addAdminModal">
                                 <i class="fa fa-plus-circle">Add Admin</i></button>
                         </div>
                     </div>
                 </h3>
                 <div class="table-responsive">
                     <table class="table">
                         <thead>
                             <tr>
                                 <th>User name</th>
                                 <th>Created date</th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php
                                $sel=mysqli_query($conn,"SELECT * FROM login_tbl");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                             <tr>
                                 <td><?php echo $row['userName'];?></td>
                                 <td><?php echo $row['createdDate'];?></td>
                             </tr>
                             <?php
                                 }
                                }
                             ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>

 <!-- Modal -->
 <div class="modal fade" id="addAdminModal" tabindex="-1" role="dialog" aria-labelledby="addAdminModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <form method="post" action="adminAction.php">
                     <div class="form-group">
                         <label for="userName">User Name</label>
                         <input required type="text" class="form-control" name="userName" id="userName" placeholder="Enter user Name">
                     </div>
                     <div class="form-group">
                         <label for="password">Password</label>
                         <input required type="password" class="form-control" name="password" id="password" placeholder="Enter password">
                     </div>

                     <button type="submit" class="btn btn-primary">Enroll</button>
                 </form>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
             </div>
         </div>
     </div>
 </div>

 <?php
include('foot.php');
?>