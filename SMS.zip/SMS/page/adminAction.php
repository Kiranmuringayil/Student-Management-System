<?php
include('../config/connection.php');

$userName = $_POST['userName'];
$password = $_POST['password'];
$today = date("Y/m/d H:i:s");

$ins = mysqli_query($conn,"insert into login_tbl(userName,password,createdDate) values('$userName','$password','$today')");

if ($ins) {
    header('location:addAdmin.php');
}
?>