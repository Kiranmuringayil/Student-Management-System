<?php
session_start();
if (isset($_SESSION['username'])) {
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    include('head.php');
?>
<div class="container-fluid">
    <div class="row bg-title">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Dashboard</h4>
        </div>
    </div>
    <!-- /.row -->
    <!-- .row -->
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8 col-xs-12">
            <div class="white-box">
                <?php
                             $sel=mysqli_query($conn,"SELECT * FROM stu_tbl,grade_tbl,branch_tbl where
                                stu_tbl.grade = grade_tbl.gradeId and stu_tbl.branch = branch_tbl.branchId 
                                and stu_tbl.id = '$id'");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                                     ?>
                <form method="post" action="updateStudent.php" class="form-horizontal form-material">
                    <input type="hidden" name="uid" value="<?php echo $row['id'];?>">
                    <div class="form-group">
                        <label for="fName">First Name</label>
                        <input required type="text" class="form-control form-control-line" name="fName" id="fName"
                            placeholder="<?php echo $row['fname'];?>">
                    </div>
                    <div class="form-group">
                        <label for="lName">Last Name</label>
                        <input required type="text" class="form-control form-control-line" name="lName" id="lName"
                            placeholder="<?php echo $row['lname'];?>">
                    </div>
                    <div class="form-group">
                        <label for="mail">Email</label>
                        <input required type="email" class="form-control form-control-line" name="mail" id="mail"
                            placeholder="<?php echo $row['mail'];?>">
                    </div>
                    <div class="form-group">
                        <label for="selGrade">Select Grade</label>
                        <select class="form-control form-control-line" name="selGrade" id="selGrade" required>
                            <option selected disabled></option>
                            <?php
                                $sel=mysqli_query($conn,"SELECT * FROM grade_tbl");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                            <option value="<?php echo $row['gradeId'];?>"><?php echo $row['grade'];?></option>
                            <?php
                                 }
                                }
                             ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="selBranch">Select Branch</label>
                        <select class="form-control form-control-line" name="selBranch" id="selBranch" required>
                            <option selected disabled></option>
                            <?php
                                $sel=mysqli_query($conn,"SELECT * FROM branch_tbl");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                            <option value="<?php echo $row['branchId'];?>"><?php echo $row['branch'];?></option>
                            <?php
                                 }
                                }
                             ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="joinDate">Date of Join</label>
                        <input type="date" class="form-control form-control-line" name="joinDate" id="joinDate"
                            required>
                    </div>
                    <button type="submit" class="btn btn-success">Update</button>
                </form>
                <?php
                                 }
                                }
                                ?>
            </div>
        </div>
    </div>
</div>
<?php    
include('foot.php');
}
}
?>