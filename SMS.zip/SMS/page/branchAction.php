<?php
include('../config/connection.php');

$branch = $_POST['branch'];

$ins = mysqli_query($conn,"insert into branch_tbl(branch) values('$branch')");

if ($ins) {
    header('location:branch.php');
}
?>