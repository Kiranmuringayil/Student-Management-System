<?php
include('../config/connection.php');

$fname = $_POST['fName'];
$lname = $_POST['lName'];
$mail = $_POST['mail'];
$grade = $_POST['selGrade'];
$branch = $_POST['selBranch'];
$joinDate = $_POST['joinDate'];

$ins = mysqli_query($conn,"insert into stu_tbl(fname,lname,mail,grade,branch,joinDate) values('$fname','$lname','$mail'
,'$grade','$branch','$joinDate')");

if ($ins) {
    header('location:index.php');
}
?>