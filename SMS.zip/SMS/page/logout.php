<?php
session_start();
if (isset($_SESSION['username'])) {
	session_unset();
//session_destroy();
//session_start();
header("location:../index.php");
}
else
{
	header("location:../index.php");
}
?>