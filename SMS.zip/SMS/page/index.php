 <?php
 session_start();
 if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="container-fluid">
     <div class="row bg-title">
         <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
             <h4 class="page-title">Dashboard</h4>
         </div>
     </div>
     <div class="row">
         <div class="col-md-12">
             <div class="white-box">
                 <h3 class="box-title">Student Management</h3>
             </div>
         </div>
     </div>
     <div class="row">
         <div class="col-sm-12">
             <div class="white-box">
                 <h3 class="box-title">
                     <div class="row">
                         <div class="col-md-2">
                             <button class="btn btn-danger btn-block waves-effect waves-light" data-toggle="modal"
                                 data-target="#addStudentModal">
                                 <i class="fa fa-plus">Add Student</i></button>
                         </div>
                     </div>
                 </h3>
                 <div class="table-responsive">
                     <table class="table" id="myTable">
                         <thead>
                             <tr>
                                 <th>First Name</th>
                                 <th>Last Name</th>
                                 <th>Grade</th>
                                 <th>Branch</th>
                                 <th></th>
                             </tr>
                         </thead>
                         <tbody>
                             <?php
                                $sel=mysqli_query($conn,"SELECT * FROM stu_tbl,grade_tbl,branch_tbl where
                                stu_tbl.grade = grade_tbl.gradeId and stu_tbl.branch = branch_tbl.branchId");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                             <tr>
                                 <td><?php echo $row['fname'];?></td>
                                 <td><?php echo $row['lname'];?></td>
                                 <td><?php echo $row['grade'];?></td>
                                 <td><?php echo $row['branch'];?></td>
                                 <td>
                                     <a href="profile.php?id=<?php echo $row['id'];?>">
                                     <button class="btn btn-info waves-effect waves-light"><i
                                             class="fa fa-eye"></i></button></a>
                                 </td>
                             </tr>
                             <?php
                                 }
                                }
                             ?>
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>

 <!-- Modal -->
 <div class="modal fade" id="addStudentModal" tabindex="-1" role="dialog" aria-labelledby="addStudentModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                 </button>
             </div>
             <div class="modal-body">
                 <form method="post" action="addStudent.php">
                     <div class="form-group">
                         <label for="fName">First Name</label>
                         <input required type="text" class="form-control" name="fName" id="fName" placeholder="Enter First Name">
                     </div>
                     <div class="form-group">
                         <label for="lName">Last Name</label>
                         <input required type="text" class="form-control" name="lName" id="lName" placeholder="Enter Last Name">
                     </div>
                     <div class="form-group">
                         <label for="mail">Email</label>
                         <input required type="email" class="form-control" name="mail" id="mail" placeholder="Enter email">
                     </div>
                     <div class="form-group">
                         <label for="selGrade">Select Grade</label>
                         <select class="form-control" name="selGrade" id="selGrade" required>
                             <option selected disabled></option>
                              <?php
                                $sel=mysqli_query($conn,"SELECT * FROM grade_tbl");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                             <option value="<?php echo $row['gradeId'];?>"><?php echo $row['grade'];?></option>
                             <?php
                                 }
                                }
                             ?>
                         </select>
                     </div>
                     <div class="form-group">
                         <label for="selBranch">Select Branch</label>
                         <select class="form-control" name="selBranch" id="selBranch" required>
                         <option selected disabled></option>
                          <?php
                                $sel=mysqli_query($conn,"SELECT * FROM branch_tbl");
                                if ($sel->num_rows>0) {
                                 while ($row=$sel->fetch_assoc()) {
                             ?>
                             <option value="<?php echo $row['branchId'];?>"><?php echo $row['branch'];?></option>
                             <?php
                                 }
                                }
                             ?>
                         </select>
                     </div>
                     <div class="form-group">
                         <label for="joinDate">Date of Join</label>
                         <input type="date" class="form-control" name="joinDate" id="joinDate" required>
                     </div>
                     <button type="submit" class="btn btn-primary">Enroll</button>
                 </form>
             </div>
             <div class="modal-footer">
                 <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
             </div>
         </div>
     </div>
 </div>

 <?php
include('foot.php');
}
?>