<?php
include('../config/connection.php');

$grade = $_POST['grade'];

$ins = mysqli_query($conn,"insert into grade_tbl(grade) values('$grade')");

if ($ins) {
    header('location:grade.php');
}
?>