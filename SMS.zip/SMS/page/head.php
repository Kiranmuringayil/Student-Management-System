<?php
include('../config/connection.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Student Management System </title>

    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/colors/default.css" id="theme" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.6/css/responsive.dataTables.min.css">
  
</head>

<body class="fix-header">

    <div id="wrapper">
        
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                
                    <a class="logo" href="index.html">
                        <img src="plugins/images/admin-logo.png" alt="home" class="dark-logo" />
                        <img src="plugins/images/admin-logo-dark.png" alt="home" class="light-logo" />
                     </a>
                </div>
                
                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <a class="profile-pic" href="logout.php"> <i class="fa fa-sign-out"></i></a>
                    </li>
                </ul>
            </div>

        </nav>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3>
                </div>
                <ul class="nav" id="side-menu">
                    <li style="padding: 70px 0 0;">
                        <a href="index.php" class="waves-effect"><i class="fa fa-dashboard fa-fw" aria-hidden="true"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="addAdmin.php" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Admin</a>
                    </li>
                    <li>
                        <a href="grade.php" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i>Grade</a>
                    </li>
                    <li>
                        <a href="branch.php" class="waves-effect"><i class="fa fa-font fa-fw" aria-hidden="true"></i>Branch</a>
                    </li>
                </ul>
            </div>
        </div>

        <div id="page-wrapper">